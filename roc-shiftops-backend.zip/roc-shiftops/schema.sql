-- ROC ShiftOps — D1 schema
-- Run with: wrangler d1 execute roc-shiftops-db --remote --file=./schema.sql

CREATE TABLE IF NOT EXISTS staff (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  dept           TEXT NOT NULL CHECK(dept IN ('ISOC','SCE')),
  role           TEXT NOT NULL CHECK(role IN ('Staff','Admin')),
  color          TEXT NOT NULL,
  pin_hash       TEXT,
  pin_salt       TEXT,
  pin_set        INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until   TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  staff_id   TEXT NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_staff ON sessions(staff_id);

CREATE TABLE IF NOT EXISTS leave_requests (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id     TEXT NOT NULL,
  name         TEXT NOT NULL,
  dept         TEXT NOT NULL,
  from_date    TEXT NOT NULL,
  to_date      TEXT NOT NULL,
  days         INTEGER NOT NULL,
  type         TEXT NOT NULL,
  reason       TEXT,
  status       TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  submitted_at TEXT NOT NULL,
  resolved_at  TEXT
);

CREATE TABLE IF NOT EXISTS swap_requests (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  from_staff   TEXT NOT NULL,
  from_name    TEXT NOT NULL,
  to_staff     TEXT NOT NULL,
  to_name      TEXT NOT NULL,
  from_date    TEXT NOT NULL,
  from_shift   TEXT NOT NULL,
  to_date      TEXT NOT NULL,
  to_shift     TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  submitted_at TEXT NOT NULL,
  resolved_at  TEXT
);

-- Approved-swap overrides applied on top of the deterministically generated
-- schedule. Only swapped cells live here — everything else is recomputed
-- on the fly from the current staff roster + approved leave.
CREATE TABLE IF NOT EXISTS schedule_overrides (
  staff_id TEXT NOT NULL,
  date     TEXT NOT NULL,   -- 'YYYY-MM-DD'
  shift    TEXT NOT NULL,
  covering INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (staff_id, date)
);

CREATE TABLE IF NOT EXISTS activities (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  type       TEXT NOT NULL,
  icon       TEXT NOT NULL,
  title      TEXT NOT NULL,
  sub        TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ── Seed roster ──────────────────────────────────────────────
-- No PINs are seeded. Each person sets their own 6-digit PIN the first
-- time they log in (pin_set starts at 0), so no plaintext PIN — old or
-- new — is ever written to the database.
INSERT INTO staff (id, name, dept, role, color) VALUES
  ('ST','Stephen','ISOC','Staff','#2D5BE3,#5A3DE8'),
  ('CH','Charles','ISOC','Admin','#7B3FE4,#6366F1'),
  ('DA','Daisy',  'ISOC','Staff','#0A8A5E,#0891B2'),
  ('TA','Tabitha','ISOC','Staff','#C22828,#7C3AED'),
  ('EU','Eugene', 'ISOC','Staff','#1A6BD1,#0E9FD8'),
  ('WA','Wayne',  'ISOC','Staff','#059669,#6366F1'),
  ('BE','Benson', 'ISOC','Staff','#7C3AED,#A855F7'),
  ('OS','Osewe',  'ISOC','Staff','#0891B2,#3D7BFF'),
  ('HI','Hilda',  'ISOC','Staff','#D97706,#EF4444'),
  ('JO','Joan',   'ISOC','Staff','#BE185D,#9333EA'),
  ('MU','Murad',  'SCE', 'Admin','#C22828,#D97706'),
  ('DV','David',  'SCE', 'Staff','#059669,#0891B2'),
  ('GR','Griffin','SCE', 'Admin','#0891B2,#6366F1'),
  ('CB','Chebet', 'SCE', 'Staff','#D97706,#EF4444'),
  ('MO','Moreen', 'SCE', 'Staff','#7C3AED,#BE185D'),
  ('PA','Patrick','SCE', 'Staff','#065F46,#0891B2');
